<?php
include 'info.php';
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<head>
<meta http-equiv="content-type" content="application/xhtml xml; charset=utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title><?php echo $title;?> - <?php echo $sitename;?></title>
<meta name="google-site-verification" content="<?php echo $gcode;?>" />
<meta name="author" content="<?php echo $author;?>"/>
<meta name="application-name" content="Youtube Video Downloader" />
<meta name="description" content="<?php echo $description;?>"/>
<meta name="keywords" content="<?php echo $title;?>,<?php echo $keywords;?> - <?php echo $sitename;?>"/>
<meta name="robots" content="index,follow"/>
<meta name="googlebot" content="index,follow">
<meta property="og:title" content="<?php echo $title;?> - <?php echo $sitename;?>"/>
<meta property="og:description" content="<?php echo $description;?> - <?php echo $sitename;?>"/>
<meta property="og:url" content="<?php echo $site;?>"/>
<meta property="og:type" content="website"/>
<meta property="og:image" content="<?php echo $mainicon;?>" />
<meta property="og:site_name" content="<?php echo $sitename;?>" />
<meta property="fb:admins" content="<?php echo $fb;?>" />
<meta property="fb:app_id" content="<?php echo $appid;?>" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:site" content="@<?php echo $twitter;?>" />
<meta name="twitter:title" content="<?php echo $title;?> - <?php echo $sitename;?>" />
<meta name="twitter:description" content="<?php echo $description;?> - <?php echo $sitename;?>" />
<meta name="twitter:url" content="<?php echo $site;?>" />
<meta name="twitter:image" content="<?php echo $mainicon;?>" />
<meta name="mobile-web-app-capable" content="yes" />
<link rel="icon" href="/images/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="/css/1.css" type="text/css"/>
<link rel="stylesheet" href="/css/2.css" type="text/css"/>
<link rel="stylesheet" href="/css/3.css" type="text/css"/>
<link rel="stylesheet" href="/css/4.css" type="text/css"/>
<link rel="stylesheet" href="/css/5.css" type="text/css"/>
<link rel="stylesheet" href="/css/6.css" type="text/css"/>
<link rel="stylesheet" href="/css/7.css" type="text/css"/>
<link rel="stylesheet" href="/css/style.css" type="text/css"/>
         <link rel="stylesheet" href="https://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css"/>
         <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
         <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js" integrity="sha256-xNjb53/rY+WmG+4L6tTl9m6PpqknWZvRt0rO1SRnJzw=" crossorigin="anonymous"></script>
         <script src="/includes/suggest.js"></script>
</head>
<body>
      <a href="/"><div class="Nayan"><center><b class="drop-shadow"><font face="serif" size="60" color="#4885ed">P</font><font face="serif" size="60" color="#db3236">q</font><font face="serif" size="60" color="#3cba54">W</font><font face="serif" size="60" color="#4885ed">a</font><font face="serif" size="60" color="#f4c20d">p</font><font face="serif" size="60" color="#db3236">.</font><font face="serif" size="60" color="#3cba54">G</font><font face="serif" size="60" color="#4885ed">a</font></b></center></div></a>
   <div align="center"><table width="100%" height="50%" cellspacing="0" cellpadding="0" border="0px" bordercolor="red"><tbody><tr> <td width="" align="center"><a href="/" class="arifn"><font color="#ebebeb"><strong><img src="/images/home_icon.png" alt="" height="20" width="20" /> Home</strong></font></a></td><td width="" align="center"><a href="http://<?php echo $forumsite;?>" class="arifn"><font color="#ebebeb"><strong><img src="/images/forum_icon.png" alt="" height="20" width="20" /> Forum</strong></font></a></td><td width="" align="center"><a href="http://<?php echo $hostingsite;?>" class="arifn"><font color="#ebebeb"><strong><img src="/images/plus_icon.png" alt="" height="20" width="20" /> Hosting</strong></font></a></td></tr></tbody></table></div>
   <div class="mainbox">
  <div class="mainblok"><form method="get" action="/search.php" class="Nayan"><table width="100%" cellpadding="0" cellspacing="0"><tbody><tr><td width="93%"><input class="search_input" type="text" name="q" style="height: 7; width: 93%;" placeholder="Search Here Anything..." id="input" autocomplete="off" required/></td> <td width="auto"><button class="srcbt" type="submit" value="Search">Search</button></td></tr></tbody></table></form></div></div>
<centre><?php echo $mainad;?></centre>