<?php
include 'includes/func.php';
include 'includes/info.php';

$title  = 'Contact Us'; // Edit Contact Title

include 'includes/head.php';
echo'<div class="mainbox"><div class="mainblok"><div class="phdr"><center>Contact Us</center></div><div class="Nayan"><center><a href="/images/admin.jpg"><img class="Nayanoldcss" src="/images/admin.jpg"/></a></center></div><div class="Nayan"><font color="grey">Name : </font><a href="http://facebook.com/'.$fb.'">'.$author.'</a> <img src="/images/verified_contact_icon.png" alt="✅" height="16px" width="16px"/></div><div class="Nayan"><font color="grey">Mobile : </font><a href="wtai://wp/mc;'.$gp.'">GP</a> . <a href="wtai://wp/mc;'.$robi.'">Robi</a> . <a href="wtai://wp/mc;'.$bl.'">BL</a> . <a href="wtai://wp/mc;'.$airtel.'">Airtel</a></div><div class="Nayan"><font color="grey">Email : </font><a href="mailto:'.$mail.'">'.$mail.'</a></div><div class="Nayan"><font color="grey">Social :   </font><a href="http://facebook.com/'.$fb.'"><img src="/images/fb_contact_icon.png" alt="FB" height="16px" width="16px"/></a>  <a href="http://twitter.com/'.$twitter.'"><img src="/images/twitter_contact_icon.png" alt="Twitter" height="16px" width="16px"/></a></div></div></div>';

include 'includes/foot.php';
?>