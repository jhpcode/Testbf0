<?php
include 'includes/func.php';

$title  = 'Download Latest Natok, Movie, Songs, Tv serial And All Type Of YouTube Videos'; //Edit Homepage Title

include 'includes/head.php';
echo'<div class="mainbox">
  <div class="mainblok">
    <div class="phdr"> <center>Recent Updates</center> </div>';
if($_GET['q']){
$q = $_GET['q'];
} else {
$a = array("Top-Music-2017");
$b = count($a)-1;
$q = $a[rand(0,$b)];
}
$qu=$q;
$qu=str_replace(" ","+", $qu);
$qu=str_replace("-","+", $qu);
$qu=str_replace("_","+", $qu);
if(strlen($_GET['page']) >1){$yesPage=$_GET['page'];}
else{$yesPage='';}
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key='.$devkey.'&part=snippet&order=relevance&maxResults=20&q='.$qu.'&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage=$json->nextPageToken;
$prevpage=$json->prevPageToken;
if($json)
{
foreach ($json->items as $sam)
{
$link= $sam->id->videoId;
$name= $sam->snippet->title;
$desc = $sam->snippet->description;
$chtitle = $sam->snippet->channelTitle;
$chid = $sam->snippet->channelId;
$date = dateyt($sam->snippet->publishedAt);
$sam = ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=contentDetails,statistics&id='.$link.'');
$linkmake = preg_replace("/[^A-Za-z0-9[:space:]]/","$1",$name);
$linkmake = str_replace(' ','-',$linkmake);
$final = strtolower("$linkmake");
$dt=json_decode($sam);
foreach ($dt->items as $dta){
$time=$dta->contentDetails->duration;
$duration= format_time($time);
$views= $dta->statistics->viewCount;   
}
echo '<div class="Nayan">';
echo '<table>';
echo '<tr>';
echo '<td width="100px" hight="95px" valign="center"><div style="position: relative;">';
echo '<a href="/video/'.$link.'/'.$final.'">';
echo '<img src="https://ytimg.googleusercontent.com/vi/'.$link.'/mqdefault.jpg" alt="'.$name.'" height="85px" width="90px" class="Nayanoldcss"><div style="position: absolute;
top: 0px; right: 0px;"> <div style="display: inline-
block; background-color: #333; opacity: 0.8;
border-radius: 0px; padding: 1px; color: #ffffff;
margin: 0px;">▶ '.$duration.' </div></div>';
echo '</a></div></td>';
echo '<td style="width=100%" valign="top">';
echo '<a href="/video/'.$link.'/'.$final.'">'.$name.'</a><table><div class="ng"><font color="green"> By <a href="/category/'.$chtitle.'"><font color="#FF0080">'.$chtitle.'</font></a>';
echo '</font>';
echo '</div>';
echo '</table>';

echo '</td></tr></table>';
echo '</div>';
}

echo '<div class="Nlister" align="center">';
if (strlen($prevpage)>1)
{
echo '<a href="/page/'.$prevpage.'">&#171;Prev</a>';}
if (strlen($nextpage)>1)
{
echo '<a href="/page/'.$nextpage.'">Next&#187;</a>';
}
echo '</div></div></div>';
}
echo '<div id="categories"><div class="mainbox"><div class="mainblok"><div class="phdr"><center>File Categories</center></div><ul><a href="/category/Bollywood Movie Songs"><li>Bollywood Movie Songs</li></a><a href="/category/Kolkata Movie Songs"><li>Kolkata Movie Songs</li></a><a href="/category/Bangla Movie Songs"><li>Bangla Movie Songs</li></a><a href="/category/Tamil Movie Songs"><li>Tamil Movie Songs</li></a><a href="/category/Hollywood Movie Songs"><li>Hollywood Movie Songs</li></a><a href="/category/Bangla Islamic Songs"><li>Bangla Islamic Songs</li></a><a href="/category/Bollywood Full Movies"><li>Bollywood Full Movies</li></a><a href="/category/Kolkata Full Movies"><li>Kolkata Full Movies</li></a><a href="/category/Bangla Full Movies"><li>Bangla Full Movies</li></a><a href="/category/Tamil Movie Hindi Dubbed"><li>Tamil Movie (Hindi Dubbed)</li></a><a href="/category/English Movie Hindi Dubbed"><li>English Movie (Hindi Dubbed)</li></a><a href="/category/China Movie Hindi Dubbed"><li>China Movie (Hindi Dubbed)</li></a><a href="/category/Bangla Natok"><li>Bangla Natok</li></a><a href="/category/Motu Patlu Bangla"><li>Motu Patlu In Bangla</li></a><a href="/more-categories.php"><li>More Categories...</li></a></ul></div></div></div>';
include 'recent_search.php';
include 'includes/foot.php';
?>