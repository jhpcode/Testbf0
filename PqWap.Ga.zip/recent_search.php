<?php
$div = "| # |";
$dat = 'recent_search_results.php';
$fp=fopen($dat, 'r');
$count=fgets($fp);
fclose($fp);
$search = $q;
$search = str_replace('+', ' ', $search);
$data = explode($div, $count);
if (in_array($search, $data)) 
{
$tulis = implode($div, $data);
$hit=$tulis;
}
else 
{
$data = explode($div, $count);
$tulis = $data[1].''.$div.''.$data[2].''.$div.''.$data[3].''.$div.''.$data[4].''.$div.''.$data[5].''.$div.''.$data[6].''.$div.''.$data[7].''.$div.''.$data[8].''.$div.''.$data[9].''.$div.''.$data[10].''.$div.''.$data[11].''.$div.''.$data[12].''.$div.''.$data[13].''.$div.''.$data[14].''.$div.''.$data[15].''.$div.''.$data[16].''.$div.''.$data[17].''.$div.''.$data[18].''.$div.''.$data[19].''.$div.''.$data[20].''.$div;
$tulis .= $search;
$hit=$tulis;
}
$cuplissayangputri=fopen($dat, 'w');
fwrite($cuplissayangputri,$tulis);
fclose($cuplissayangputri);
$fa=fopen($dat, 'r');
$b=fgets($fa);
fclose($fa);
$c = explode($div, $b);
echo '<div class="mainbox">
  <div class="mainblok">';
echo '<div class="phdr"> <center>Recent Search</center> </div><div class="Nayan">';
foreach(array_reverse($c) as $d)
{
echo '<a style="padding: 3px; display:inline-block" href="/category/'.$d.'">'.$d.'</a> &middot;';
}
echo ' </div>
     </div>
   </div>';
?>
