<?php
include 'includes/func.php';

$title  = 'About Us'; // Edit About Us Title

include 'includes/head.php';
echo'<div class="mainbox"><div class="mainblok"><div class="phdr"><center>About Us</center></div><div class="Nayan">This is a Free Mobile Videos and Audios Content Provide Site. Where You Can Download latest Musics, Natok, Movies, Cartoons, Islamic Videos or Audios. Are Anything That Can Be Viewed And Enjoyed On Mobile Devices.</div></div></div>';

include 'includes/foot.php';
?>