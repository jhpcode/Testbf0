<?php
include 'includes/func.php';

$title  = 'Advertise with Us'; // Edit Advertise Title

include 'includes/head.php';
echo'<div class="mainbox"><div class="mainblok"><div class="phdr"><center>Advertise</center></div><div class="Nayan">For any kind of advertise you can <a href="/contact-us.php">Contact Us.</a></div></div></div>';

include 'includes/foot.php';
?>