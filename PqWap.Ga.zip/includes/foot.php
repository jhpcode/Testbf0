<?php
include 'includes/info.php';
?>
<footer> <p><div class="mfooter"><div align="center"><div id="down"></div><div class="mtt" align="center"><a href="https://facebook.com/dialog/share?app_id=<?php echo $appid;?>&display=popup&href=<?php echo $site;?>&redirect_uri=http://facebook.com"><img src="/images/fb_share_icon.png" width="70px" height="35px" alt="Share"/></a> <img src="/images/and_icon.png" width="20px" height="20px" alt="or"/> <a href="https://twitter.com/intent/tweet?text=<?php echo $title;?>&related=twitter.com&url=<?php echo $site;?>"><img src="/images/twitter_tweet_icon.png" width="76px" height="35px" alt="Tweet"/></a></div></div><div class="mtb"> </div><ul class="mleft"><li> <a href="/">Home</a></li><li><a href="/contact-us.php">Contact Us</a></li>
<li><a href="/disclaimer.php">Disclaimer</a></li> </ul><span style="float:top"><ul class="mright">
<li><a href="/about-us.php">About Us</a></li>
<li> <a href="/privacy-and-policy.php">Privacy & Policy</a></li>
<li> <a href="/advertise.php">Advertise</a></li>
</ul></span><div style="clear: both;display: yes;"></div><div align="center"><div class="wapka"> <div/> <div/> <div/></div> <div class="mfooter"><div class="" align="center"><font color="white">All Rights Reserved by </font><a name="online" href="http://facebook.com/<?php echo $fb;?>"><font color="gold">Jahid</font></a><span style="color:white;"></span></div></div></div></div></p> </footer>
</body>
</html>
