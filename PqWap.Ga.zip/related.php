<?php
include 'includes/info.php';
echo '<div class="mainbox">
  <div class="mainblok">
    <div class="phdr"> <center>Related Videos</center> </div>';
echo ''.$yllix.'';
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key='.$devkey.'&part=snippet&maxResults=10&relatedToVideoId='.$_GET['id'].'&type=video');
$json = json_decode($grab);
if($json)
{
foreach ($json->items as $hasil)
{
$link= $hasil->id->videoId;
$name= $hasil->snippet->title;
$desc = $hasil->snippet->description;
$chtitle = $hasil->snippet->channelTitle;
$chid = $hasil->snippet->channelId;
$date = dateyt($hasil->snippet->publishedAt);
$hasil = ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=contentDetails,statistics&id='.$link.'');
$linkmake = preg_replace("/[^A-Za-z0-9[:space:]]/","$1",$name);
$linkmake = str_replace(' ','-',$linkmake);
$final = strtolower("$linkmake");
$dt=json_decode($hasil);
foreach ($dt->items as $dta){
$time=$dta->contentDetails->duration;
$duration= format_time($time);
$views= $dta->statistics->viewCount;   
}
echo '<div class="Nayan">';
echo '<table>';
echo '<tr>';
echo '<td width="100px" hight="95px" valign="center"><div style="position: relative;">';
echo '<a href="/video/'.$link.'/'.$final.'">';
echo '<img src="https://ytimg.googleusercontent.com/vi/'.$link.'/mqdefault.jpg" alt="'.$name.'" height="85px" width="90px" class="Nayanoldcss"><div style="position: absolute;
top: 0px; right: 0px;"> <div style="display: inline-
block; background-color: #333; opacity: 0.8;
border-radius: 0px; padding: 1px; color: #ffffff;
margin: 0px;">▶ '.$duration.' </div></div>';
echo '</a></div></td>';
echo '<td style="width=100%" valign="top">';
echo '<a href="/video/'.$link.'/'.$final.'">'.$name.'</a><table><div class="ng"><font color="green"> By <a href="/category/'.$chtitle.'"><font color="#FF0080">'.$chtitle.'</font></a>';
echo '</font>';
echo '</div>';
echo '</table>';

echo '</td></tr></table>';
echo '</div>';
}
echo '</div></div>';
}
?>