<?php
include 'includes/func.php';

$title  = 'Privacy and Policy'; // Edit Privacy Title

include 'includes/head.php';
echo'<div class="mainbox"><div class="mainblok"><div class="phdr"><center>Privacy & Policy</center></div><div class="Nayan">If you require any more information or have any questions about our privacy policy, please feel free to contact us.
At the privacy of our visitors is of extreme importance to us. This privacy policy document outlines the types of personal information is received and collected by Website and how it is used.<p><h2>Log Files</h2></p>Like many other Web sites, We makes use of log files. The information inside the log files includes internet protocol ( IP ) addresses, type of browser, Internet Service Provider ( ISP ), date/time stamp, referring/exit pages, and number of clicks to analyze trends for the improvement of user experience.<p><h2>Cookies and Web Beacons</h2></p>We does use cookies to store information about visitors preferences, record user-specific information on which pages the user access or visit, customize Web page content based on visitors browser type or other information that the visitor sends via their browser.</div></div></div>';

include 'includes/foot.php';
?>