<?php

$site = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'';

$host = $_SERVER['HTTP_HOST'];

$sitename = 'PqWap.Ga'; // Site Name

$forumsite = 'm.PqWap.Ga'; // Forum Site Name

$videoad = ''; // Video Page AD

$mainad = ''; // All Page AD

$hostingsite = 'PqWap.mL'; // Hosting Site Name

$mainicon = 'http://'.$_SERVER['HTTP_HOST'].'/images/social_icon.png'; // Head Main Sharing Icon

$videoicon = 'https://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/0.jpg'; // Head Video Sharing Icon

$appid = '162331364606476'; // Facebook App ID

$fb = 'JhpJahid'; // Facebook Username

$twitter = 'JhpJahid'; // Twitter Username

$gcode = 'jRBDCGP_t8M7uoqeJ2RNQ1JK7Hi5jP9Z-p0zvupFM3E'; // Google Verification Code

$author = 'Jhp Jahid'; // Author Name

$gp = '+8801727429929'; // gp number

$bl = '+8801905713878'; // bl number

$robi = '+8801875157683'; // robi number

$airtel = '+8801683359243'; // airtel number

$mail = 'JhpJahid@Gmail.Com'; // Email Address

$description = 'Download Youtube videos in all available formats. Download all types Youtube videos including vevo videos or age protected videos. Best Youtube video Downloader ever'; // Site Description

$videodescription = ''.$des.''; // Head Video Sharing Description

$keywords = 'online 3gp video,watch video sexy,youtube comedy videos,fun clips video,kissing video on youtube,kiss videos youtube,how to kiss video youtube,video kissing youtube,man to man movie,three x movie,movie xx,x movie s,x movie x,x moive,x australian moviesex sex sex movie,saex film,sex the movie,the most sexual movie,sex in the movie,movie sex part,kids english songs,english new songs,list of latest english songs,new music english,new latest english songs,song english new,latest english albums,latest top english songs ,new songs of english,latest best english songs,kids videos songs,bhojpuri hot item song,youtube bhojpuri hot item songs,new item songs,new sexy songs,top sexy songs,sexy songs to sing,best music for sex,list of sexy songs,video clip,video hd download,hd mobile movies download,download mp4 free,hd mp4 download,www videos mp4 com,download free mp4 ,videos mp4 com,3gp hd,watch news videos,where to watch videos,music video search,mp4 hd movies free download ,love positions,&#2476;&#2441; &#2447;&#2480; &#2470;&#2497;&#2471;,eva makeup lab,el gran torneo mortal,minecraft_1.8_skin_converter, kairalionline,crime petrol Episode,Hindi music video HD, 1080p, mp4, avi, mkv, kickass download, dvd rip movie, Mp3 128bit, 192bit, 320bit mp3 Download, Bollywood music video,2016 full movie,movies 2016 full,horror movies 2016,english 2016 chinese,kapoor and sons kickass,cize kickass,batman film download,hindi movie download,hindi free movies download,download bollywood movies,bollywood movies download,download hindi movies,download film,free bollywood movies download,new hindi movie download,download free hindi movies,latest hindi movies download,mp4 movies download,hindi film download,mp4 videos free download,hindi movies downloader free,indian movie download,download hindi movies free,download latest hindi movies,mp4 video downloader,hd bollywood movies free download,download video mp4,download hindi movies in hd,hd movies free download bollywood,hindi movie download site,3gp mobile movies bollywood,download mp4 movies,Video downloader, download youtube, video download, youtube video, youtube downloader, download youtube FLV, download youtube MP4, download youtube 3GP, php video downloader,Free Mobile Ringtones, Desh Bhakti Songs, Old Sonngs, Bollywood Songs, Wallpaper, Videos, Animations And More services,songs, desh bhakti songs, old Sonngs, ringtones, wallpapers,HD Videos, funny videos, Free HD Videos, Ringtones, Wallpapers, Themes, Games, Softwares, Mp3 Songs, Videos,Funny videos, Free HD Videos, Ringtones, Wallpapers, Themes, Games, Softwares, Mp3 Songs, Videos';
?>