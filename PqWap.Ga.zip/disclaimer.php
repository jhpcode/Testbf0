<?php
include 'includes/func.php';

$title  = 'Disclaimer'; // Edit Disclaimer Title

include 'includes/head.php';
echo'<div class="mainbox"><div class="mainblok"><div class="phdr"><center>Disclaimer</center></div><div class="Nayan">This is a promotional website only, All files placed here are for introducing purpose only
Please, buy original Songs/contents from author or developer site!
If you do not agree to all the terms, please disconnect from this site now itself.
By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth
All files found on this site have been collected from various sources across the web and are believed to be in the Public Domain.
All the logos and stuff are the property of their respective owners.
If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, Please Contact Us We will remove it in 24 hour.</div></div></div>';

include 'includes/foot.php';
?>