<?php
include 'includes/func.php';
include 'includes/info.php';
$yf=ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=snippet,contentDetails,statistics,topicDetails&id='.$_GET['id'].'');
$yf=json_decode($yf);


if($yf){
foreach ($yf->items as $item)
{

$name=$item->snippet->title;
$des = $item->snippet->description;
$date = dateyt($item->snippet->publishedAt);
$channelId = $item->snippet->channelId;
$chtitle = $item->snippet->channelTitle;
$ctd=$item->contentDetails;
$duration=format_time($ctd->duration);
$hd = $ctd->definition;
$st= $item->statistics;
$views = $st->viewCount;
$likes = $st->likeCount;
$dislike = $st->dislikeCount;
$favoriteCount = $st->favoriteCount;
$commentCount = $st->commentCount;
{$title='Download '.$name.' Video or Mp3 File';}
$tag=$name;
$tag=str_replace(" ",",", $tag);
$dtag=$des;
include 'includes/ihead.php';
echo '<div class="mainbox">
  <div class="mainblok">
    <div class="phdr"> <center>'.$name.'</center> </div>';
echo '<div class="Nayan" align="center"><iframe class="Nayanoldcss" align="center" width="300" height="200" src="//www.youtube.com/embed/'.$_GET['id'].'" frameborder="0" allowfullscreen></iframe> <br/>
<img src="http://img.youtube.com/vi/'.$_GET['id'].'/1.jpg" width="90" height="auto" alt="'.$name.'"/><img src="http://img.youtube.com/vi/'.$_GET['id'].'/2.jpg" width="90" height="auto" alt="'.$name.'"/><img src="http://img.youtube.com/vi/'.$_GET['id'].'/3.jpg" width="90" height="auto" alt="'.$name.'"/></div>  <div class="Nayan"> <b>Duraration : </b>'.$duration.'</div>
  <div class="Nayan"> <b>Channel : </b><a href="/category/'.$chtitle.'">'.$chtitle.'</a></div>
  <div class="Nayan"> <b>Upload On : </b>'.$date.'</div>
  <div class="Nayan"> <b>Views : </b>'.$views.'</div>
  <div class="Nayan"> <b>Likes : </b>'.$likes.'</div>
  <div class="Nayan"> <b>Dislikes : </b>'.$dislike.'</div>
<div class="Nayan"><font color="grey">Share On :   </font><a href="https://facebook.com/dialog/share?app_id='.$appid.'&display=popup&href='.$site.'&redirect_uri=http://facebook.com"><img src="/images/fb_contact_icon.png" alt="FB" height="18px" width="18px"/></a>  <a href="https://twitter.com/intent/tweet?text='.$title.'&related=twitter.com&url='.$site.'"><img src="/images/twitter_contact_icon.png" alt="Twitter" height="18px" width="18px"/></a></div></div></div>';
echo '<div class="mainbox">
  <div class="mainblok">
    <div class="phdr"><center>Download Links</center></div>';
echo '<a href="http://ss.prx.genyoutube.com/s77.ytapi.us/samapi.php?id='.$_GET['id'].'&itag=17"><div class="Nayan">Download 3GP Low [176x144]</div></a><a href="http://ss.prx.genyoutube.com/s77.ytapi.us/samapi.php?id='.$_GET['id'].'&itag=36"><div class="Nayan">Download 3GP High [320x240]</div></a><a href="http://ss.prx.genyoutube.com/s77.ytapi.us/samapi.php?id='.$_GET['id'].'&itag=18"><div class="Nayan">Download MP4 [360x640]</div></a><a href="http://ss.prx.genyoutube.com/s77.ytapi.us/samapi.php?id='.$_GET['id'].'&itag=43"><div class="Nayan">Download WebM [360x640]</div></a><a href="http://s77.ytapi.us/samapi.php?id='.$_GET['id'].'&itag=22"><div class="Nayan">Download MP4 (HD) [720x1280]</div></a><a href="http://www.convertmp3.io/fetch/?video=https://www.youtube.com/watch?v='.$_GET['id'].'"><div class="Nayan">Download MP3 [256 Kbps]</div></a><a href="http://odg.youtube6download.top/cnvx.php?id='.$_GET['id'].'&type=Download"><div class="Nayan">Download MP3 [192 Kbps]</div></a><a href="http://ss.prx.genyoutube.com/s77.ytapi.us/samapi.php?id='.$_GET['id'].'&itag=140"><div class="Nayan">Download MP3 [128 Kbps]</div></a></div></div>';
echo '<div class="mainbox">
  <div class="mainblok">
    <div class="phdr"><center>Description</center></div>';
echo '<div class="Nayan">'.$des.'</div></div></div>';
}
}

include 'related.php';
include 'recent_search.php';
include 'includes/foot.php';
?>